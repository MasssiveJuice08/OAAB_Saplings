Version 2.3.0
- Added patch for [OAABBrotherJunipersTwinLamps](https://www.nexusmods.com/morrowind/mods/51424) by Lucevar.

Version 2.2.1
- Fixed additional clipping sapling in BCOM patch.

Version 2.2.0
- Added patch for [Minor Plantations Redone](https://www.nexusmods.com/morrowind/mods/54537) by Endify 123.

Version 2.1.2
- Fix Gnisis floaters in BCOM patch that had OpenMW engine issue.
- Fixed most error log warnings with the patch.
- Updated archive to be BAIN installer compatible.
- Updated fomod.

Version 2.1.1
- Fixed BCOM patch not having its LawnMowered saplings deleted. Now has had Tes3cmd ran correctly on it.
- Updated and re-added FOMOD, omitted from previous update by mistake.

Version 2.1.0
- Run autoclean_cities_vanilla.esp from LawnMower tool on ESM and move clipping groundcover. Tes3cmd delete the references on the ESM and all the patches.
- Rename Concept Arts Plantations plugin as it is compatible with or without BCOM out of the box.
- few fixes in BCOM patch and Concept Arts Plantations patch.

Version 2.0.0
- Complete overhaul of original mod, merging in features from 'OAAB Saplings OpenMW Groundcover Patch'
- Sapling placement trimmed with 'The Lawnmower' tool by Acidzebra
- merged ESP replaced with an ESM
- patches added for BCOM, 'Concept Arts Plantations' (BCOM version), 'The Great Seawall of Vivec', 'The Stonewood Pass Reworked', and 'The Road to the Lighthouse'
- modular regional ESPs replaced with region remover ESPs which optionally remove saplings from specified regions
- FOMOD installer added

Version 1.5.0
- Cleaned up some placement in WG and AI modules
- Fixed exterior cell "illegal to rest" flags for some settlements

Version 1.4.0
- Separated Sheogorad into its own regional plugin

Version 1.3.0
- Cleaned up some placement in the AI and WG regions (special thanks to Lucevar for the AI module - expect better compatibility with BCoM in that region with this update)

Version 1.2.0
- Added and merged correct version of the WG plugin which cleans up placement
- Cleaned plugins

Version 1.1.0
- Added optional merged plugin

Version 1.0.0
- Initial release
