Version 2.0.0
- Complete overhaul of original mod, merging in features from 'OAAB Saplings OpenMW Groundcover Patch'
- Sapling placement trimmed with 'The Lawnmower' tool by Acidzebra
- merged ESP replaced with an ESM
- patches added for BCOM, 'Concept Arts Plantations' (BCOM version), 'The Great Seawall of Vivec', 'The Stonewood Pass Reworked', and 'The Road to the Lighthouse'
- modular regional ESPs replaced with region remover ESPs which optionally remove saplings from specified regions
- FOMOD installer added

Version 1.5.0
- Cleaned up some placement in WG and AI modules
- Fixed exterior cell "illegal to rest" flags for some settlements

Version 1.4.0
- Separated Sheogorad into its own regional plugin

Version 1.3.0
- Cleaned up some placement in the AI and WG regions (special thanks to Lucevar for the AI module - expect better compatibility with BCoM in that region with this update)

Version 1.2.0
- Added and merged correct version of the WG plugin which cleans up placement
- Cleaned plugins

Version 1.1.0
- Added optional merged plugin

Version 1.0.0
- Initial release