Version 1.1.2
- Updated `03 OSOGP - OAAB_Saplings_AC BCOM patch` to fix floaters in Tel Aruhn (credit: Sophie).
- Added patch for 'The Road to Vivec Lighthouse' by RandomPal, deleting saplings from the road in cells 2,-14 and 3,-15. Compatible with other AI patches.

Version 1.1.0
- Added `05 OSOGP - Great Seawall of Vivec + BCOM + Concept Art Plantations Combined`.
- Restructured folders.
- Added FOMOD installer.

Version 1.0.9
- Added `06 BCOM + Concept Art Plantations` patch (credit: Sophie)

Version 1.0.8
- Added patch for The Great Seawall of Vivec, created by Sophie on MMC Discord - removes saplings from the walkway in cells 6,-13; 6,-14; 7,-13.

Version 1.0.7
- Updated '01 BCOM patch for OAAB_Saplings_WG', fixing floaters and clipping meshes in cell Balmora -2,-2 (credit: Sophie)

Version 1.0.6
- Added a regular BCOM (minus Stonewood Pass) patch for OAAB_Saplings_WG, created by Sophie on MMC. Edits saplings in cell: Balmora -3,-2.

Version 1.0.5
- Added a BCOM patch for OAAB_Saplings_AC (Credit to Sophie on MMC for the fix)

Version 1.0.4
- Removed optional patch for 'Vanilla-friendly West Gash Tree Replacer', as the original mod does not require a patch for OAAB saplings anymore.
- Updated plugins to latest version of OAAB_Data

Version 1.0.2
- Updated to version 2.1.1 of OAAB Data. Included OAAB_Saplings_WG.esp and 'Graht Morrowind Swamp Trees patch' which were mistakenly omitted from version 1.01 of this mod

Version 1.0.1
- Updated to version 2.1.0 of OAAB_Data

Version 1.0.0
- Initial Release